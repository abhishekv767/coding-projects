#ifndef ES_General_H
#define ES_General_H

#define ARRAY_SIZE(x)  (sizeof(x)/sizeof(x[0]))

#endif//ES_General_H