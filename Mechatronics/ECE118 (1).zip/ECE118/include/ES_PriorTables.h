#ifndef ES_PRIOR_TABLES_H
#define ES_PRIOR_TABLES_H

uint8_t GetMSBitNum( uint8_t Value );


uint8_t GetClearMask( uint8_t BitNum );


uint8_t GetSetMask( uint8_t BitNum );
#endif
